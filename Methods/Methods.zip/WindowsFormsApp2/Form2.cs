﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        char opt;
        int num;
        double total = 0;   
        public Form2()
        {
            InitializeComponent();
        }
        public void ScanData(char opt, int num)
        {   
            this.opt = opt;
            this.num = num;
        }

        public void DoNextOperation(char opt, int num)
        {

         

            switch (opt)
            {
                case '+':
                    total += num;
                   listBox1.Items.Add("Result so far is: " +total);
                    break;
                case '^':
                    total = Math.Pow(total, num);
                    listBox1.Items.Add("Result so far is: " + total);
                    break;
                case '/':
                    total /= num;
                    listBox1.Items.Add("Result so far is: " + total);
                    break;
            }
        
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
