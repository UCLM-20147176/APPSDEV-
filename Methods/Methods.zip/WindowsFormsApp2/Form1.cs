﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        Form2 hub = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            hub.Show();
            char opt = Convert.ToChar(textBox1.Text);
            int num = Convert.ToInt32(textBox2.Text);

            
            hub.DoNextOperation(opt, num);
            

        }
    }
}
