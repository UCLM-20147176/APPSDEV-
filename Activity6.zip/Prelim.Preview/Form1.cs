﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prelim.Preview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = Convert.ToString(textBox1.Text);
            string country = Convert.ToString(textBox2.Text);

            string gender = "";
            if (rdbmale.Checked)
            {
                gender = " Male";
            }
            else if (rdbfemale.Checked)
            {
                gender = "Female";
            }

            string hobby = " ";
            if (chkread.Checked)
            {
                hobby = "Reading";
            }
            else if (chkpaint.Checked)
            {
                hobby = "Painting";
            }
            

            string status = " ";
            if (rdbSingle.Checked)
            {
                status = "Single";
            }
            else if (rdbMarry.Checked)
            {
                status = "Married";
            }




            Display hub = new Display();
            hub.show(name, country, gender, hobby, status);
            hub.Show();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdbSingle_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
