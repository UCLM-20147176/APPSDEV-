﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prelim.Preview
{
    public partial class Display : Form
    {
        public Display()
        {
            InitializeComponent();
        }
        public void show(string name, string country, string gender, string hobby, string status)
        { 
            label10.Text = name;
            label9.Text = country;
            label8.Text = gender;
            label7.Text = hobby;
            label6.Text = status;



        }

        public void check()
        { 
        
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Display_Load(object sender, EventArgs e)
        {

        }
    }
}
