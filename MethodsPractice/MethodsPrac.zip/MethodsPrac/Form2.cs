﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MethodsPrac
{
    public partial class Form2 : Form
    {
        double num;
        char oper;
        double total = 0;
        public Form2()
        {
            InitializeComponent();
        }
       public void ScanData(char oper, double num)
        {
            this.num = num;
            this.oper = oper;
            
        }
        public void DoNextOperation(char oper, double num)
        {
            
            switch (oper)
            {
                case '+':
                    listBox1.Items.Add($"{oper} {num}");
                    total = total + num; 
                    listBox1.Items.Add("Result so far is: " +total);
                    break;
                case '-':
                    listBox1.Items.Add($"{oper} {num}");
                    total = total - num;
                    listBox1.Items.Add("Result so far is: " +total);
                    break;
                case '*':
                    listBox1.Items.Add($"{oper} {num}");
                    total = total * num;
                    listBox1.Items.Add("Result so far is: ");
                    break; 
                case '/':
                    listBox1.Items.Add($"{oper} {num}");
                    total = total / num;
                    listBox1.Items.Add("Result so far is: " +total);
                    break;
                case '^':
                    total = Math.Pow(num, total);
                    listBox1.Items.Add($"{oper} {num}");
                    listBox1.Items.Add("Result so far is: " +total);
                    break;
                case 'q':
                    listBox1.Items.Add($"{oper} {num}");
                    listBox1.Items.Add("Final result is: " +total);
                   // Close();
                    break;
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
