﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PassingArrayFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            const int TOTAL_NUMBERS = 2;
            int[] numbers = new int[TOTAL_NUMBERS];
            string[] lines = richTextBox1.Lines;

            for (int i = 0; i < numbers.Length; i++)
            {

                numbers[i] = Convert.ToInt32(lines[i]);
            }

            //Console.WriteLine("Before invoking swap");
            label1.Text = ("array is {" + lines[0] + ", " + lines[1] + "}");
            swap(numbers[0], numbers[1]);
            //Console.WriteLine("After invoking swap");
            label2.Text = ("array is {" + lines[0] + ", " + lines[1] + "}");
            // Swap elements using the swapFirstTwoInArray method
            //  Console.WriteLine("Before invoking swapFirstTwoInArray");
            label3.Text = ("array is {" + lines[0] + ", " + lines[1] + "}");
            swapFirstTwoInArray(numbers);
            // Console.WriteLine("After invoking swapFirstTwoInArray");
            label4.Text = ("array is {" + numbers[0] + ", " + numbers[1] + "}");
        }
        /** Swap two variables */
        public static void swap(int n1, int n2)
        {
            int temp = n1;
            n1 = n2;
            n2 = temp;
        }
        /** Swap the first two elements in the array */
        public static void swapFirstTwoInArray(int[] array)
        {
            int temp = array[0];
            array[0] = array[1];
            array[1] = temp;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
 }


