﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Registration
    {
        private string firstname;
        private string lastname;
        private int age;

        public Registration(string firstname, string lastname, int age) 
        {
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age ;
        }

        public string getFirstname()
        { 
            return this.firstname;
        }

        public string getLastname()
        {
            return this.lastname;
        }

        public int getAge()
        {
            return this.age;
        }

        public void displayInfo()
        {
            Console.WriteLine("Name: " +getFirstname());
            Console.WriteLine("Lastname: " +getLastname());
            Console.WriteLine("Age: " +getAge());
        }

    }
}
