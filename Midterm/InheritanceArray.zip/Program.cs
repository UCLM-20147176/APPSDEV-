﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstname, lastname, coursedesc, workdesc;
            int age, yearlevel, noOfExperience;

            Work_Experience[] people = new Work_Experience[3];

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Person " +(i + 1));
                Console.Write("Enter firstname: ");
                firstname = Console.ReadLine();
                Console.Write("Enter lastnaname: ");
                lastname = Console.ReadLine();
                Console.Write("Enter Age: ");
                age = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter course: ");
                coursedesc = Console.ReadLine();
                Console.Write("Enter yearlevel: ");
                yearlevel = Convert.ToInt32(Console.ReadLine());


                Console.Write("Enter work experience: ");
                workdesc = Console.ReadLine();
                Console.Write("Enter No of Experience: ");
                noOfExperience = Convert.ToInt32(Console.ReadLine());

                people[i] = new Work_Experience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noOfExperience);

            }
                Console.WriteLine(" ");
            for (int i = 0; i < 3; i++)
            {
                people[i].displayInfo();
                Console.WriteLine(" ");
                
            }
            Console.ReadKey();
        }
    }
}
