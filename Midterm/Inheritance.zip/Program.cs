﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstname, lastname, coursedesc, workdesc;
            int age, yearlevel, noOfExperience;


            
            Console.Write("Enter firstname: ");
            firstname = Console.ReadLine();
            Console.Write("Enter lastnaname: ");
            lastname = Console.ReadLine();
            Console.Write("Enter Age: ");
            age = Convert.ToInt32(Console.ReadLine());
           
            Console.Write("Enter course: ");
            coursedesc = Console.ReadLine();
            Console.Write("Enter yearlevel: ");
            yearlevel = Convert.ToInt32(Console.ReadLine());
           

            Console.Write("Enter work experience: ");
            workdesc = Console.ReadLine();
            Console.Write("Enter No of Experience: ");
            noOfExperience = Convert.ToInt32(Console.ReadLine());

            Work_Experience plar = new Work_Experience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noOfExperience);
            plar.displayInfo();

            Console.ReadKey();

        }
    }
}
