﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Work_Experience : Course
    {
        private string workdesc;
        private int noOfExperience;
        public Work_Experience(string firstname, string lastname, int age, string coursedesc, int yearlevel, string workdesc, int noOfExperience) : base(firstname, lastname, age, coursedesc, yearlevel)
        {
            this.workdesc = workdesc;
            this.noOfExperience = noOfExperience;
        }

        public string getWorkdesc() 
        { 
            return this.workdesc;
        }

        public int getNoOfExperience()
        {
            return this.noOfExperience;
        }

        public override void displayInfo()
        {
            base.displayInfo();
            Console.WriteLine("Work Experience: " +getWorkdesc());
            Console.WriteLine("No. Of Experience: " +getNoOfExperience());
        }
    }
}
