﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestingArrays
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                //declaration of constant variable
                const int TOTAL_NUMBERS = 6;
                int[] numbers = new int[TOTAL_NUMBERS];
                string[] lines = txtnumber.Lines;

                for (int i = 0; i < numbers.Length; i++)
                {

                    numbers[i] = Convert.ToInt32(lines[i]);
                }
                // Find the largest
                int min = numbers[0];
                for (int i = 1; i < numbers.Length; i++)
                {
                    if (min > numbers[i])
                        min = numbers[i];
                }
                // Find the occurrence of the largest number
                int count = 0;
                for (int i = 0; i < numbers.Length; i++)
                {
                    if (numbers[i] == min) count++;
                }
                // Prepare the result
                String output = "The array is ";
                for (int i = 0; i < numbers.Length; i++)
                {
                    output += numbers[i] + " ";
                }
                output += "\nThe smallest number is " + min;
                output += "\nThe occurrence count of the smallest number "
                + "is " + count;
            // Display the result
            label1.Text = Convert.ToString(output);


        }
    }
}
