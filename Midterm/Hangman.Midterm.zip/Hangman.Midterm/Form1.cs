﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hangman.Midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string clue = txtclue.Text;         
            string wordToGuess = textBox1.Text.ToUpper();
            
            // Create character array with asterisks
            char[] hiddenWord = new char[wordToGuess.Length];
            for (int i = 0; i < hiddenWord.Length; i++)
            {
                hiddenWord[i] = '*';
            }

            Form2 hub = new Form2();
            hub.Clue(clue);
            hub.StartGame(hiddenWord, wordToGuess);
            hub.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void txtclue_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
