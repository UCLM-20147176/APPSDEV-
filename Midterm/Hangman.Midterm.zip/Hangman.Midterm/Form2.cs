﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hangman.Midterm
{
    public partial class Form2 : Form
    {
        private char[] hiddenWord;
        private string wordToGuess;
        private int wrongGuesses = 0;

        public Form2()
        {
            InitializeComponent();
            
        }

        public void Clue(string clue)
        {
            label2.Text = clue.ToString();
        }

        public void StartGame(char[] hidden, string word)
        {
            hiddenWord = hidden;
            wordToGuess = word;

            // Update label with initial hidden word (asterisks)
            label3.Text = new string(hiddenWord);
            label4.Text = "Wrong Guesses: " + wrongGuesses; // Update wrong guess label
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 1)
            {
                MessageBox.Show("Please enter only one letter.");
                textBox1.Text = ""; // Clear textbox after error
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                return; // Do nothing if empty
            }
            
        }


        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string guess = textBox1.Text.ToUpper();
            textBox1.Text = ""; // Clear textbox after guess

            // Check if guess is valid (a single letter)
            bool guessFound = false;
            for (int i = 0; i < wordToGuess.Length; i++)
            {
                if (wordToGuess[i] == guess[0])
                {
                    hiddenWord[i] = guess[0];
                    guessFound = true;
                }
            }

            if (guessFound)
            {
                label3.Text = new string(hiddenWord);
            }
            else
            {
                wrongGuesses++;
                label4.Text = "Wrong Guesses: " + wrongGuesses;
            }

            // Check win/lose condition (all letters revealed or wrong guess limit reached)
            if (new string(hiddenWord) == wordToGuess)
            {
                Form3 hub = new Form3();
                hub.Show();
                this.Hide();
            }
            else if (wrongGuesses >= 6)
            {
                Form4 hub = new Form4();
                hub.Show();
                this.Hide();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
