﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hangman.Midterm
{
    public partial class Form2 : Form
    {
        private char[] hiddenWord;
        private string wordToGuess;
        private int wrongGuesses = 0;
        private Image[] hangmanImages;

        public Form2()
        {
            InitializeComponent();
            LoadHangmanImages();

        }
        private void LoadHangmanImages()
        {
            hangmanImages = new Image[6];
            for (int i = 0; i < 6; i++)
            {
                string imagePath = Path.Combine(Application.StartupPath, $"hang{i + 1}.png");             
                // Check the image if available
                if (File.Exists(imagePath))
                {
                    hangmanImages[i] = Image.FromFile(imagePath);
                }
                else
                {
                    MessageBox.Show($"Image not found: {imagePath}");
                }
                
            }
        }

        public void Clue(string clue)
        {
            label2.Text = clue.ToString();
        }

        public void StartGame(char[] hidden, string word)
        {
            hiddenWord = hidden;
            wordToGuess = word;

            // Update label with asterisks
            label3.Text = new string(hiddenWord);
            label4.Text = "Wrong Guesses: " + wrongGuesses; 
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 1)
            {
                MessageBox.Show("Please enter only one letter.");
                textBox1.Text = ""; 
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                return; 
            }
            
        }


        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string guess = textBox1.Text.ToUpper();
            textBox1.Text = ""; 

            // Check if the guess of user is valid 
            bool guessFound = false;
            for (int i = 0; i < wordToGuess.Length; i++)
            {
                if (wordToGuess[i] == guess[0])
                {
                    hiddenWord[i] = guess[0];
                    guessFound = true;
                }
            }

            if (guessFound)
            {
                label3.Text = new string(hiddenWord);
            }
            else
            {
                wrongGuesses++;
                label4.Text = "Wrong Guesses: " + wrongGuesses;
            }

            if (wrongGuesses >= 0 && wrongGuesses < hangmanImages.Length)
            {
                pictureBox1.Image = hangmanImages[wrongGuesses];
            }

            // Win or Lose if else statement
            if (new string(hiddenWord) == wordToGuess)
            {
                Form3 hub = new Form3();
                hub.Show();
                this.Hide();
            }
            else if (wrongGuesses >= 6)
            {
                Form4 hub = new Form4();
                hub.Show();
                this.Hide();
            }
        }



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
